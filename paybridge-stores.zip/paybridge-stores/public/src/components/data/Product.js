const products = [
    {
      id: "1",
      name: "Wireless Earbuds",
      description: "High-quality sound with long battery life.",
      price: 15000,
      image:
        "https://images.unsplash.com/photo-1606813908330-cd4b14f87aa6?auto=format&fit=crop&w=800&q=80",
    },
    {
      id: "2",
      name: "Smart Watch",
      description: "Track fitness and notifications.",
      price: 25000,
      image:
        "https://images.unsplash.com/photo-1611222538590-9c5cb7d16a02?auto=format&fit=crop&w=800&q=80",
    },
    {
      id: "3",
      name: "Power Bank",
      description: "Fast-charging 10000mAh battery.",
      price: 10000,
      image:
        "https://images.unsplash.com/photo-1624904135673-49aa34ce5c18?auto=format&fit=crop&w=800&q=80",
    },
  ];
  
  export default products;